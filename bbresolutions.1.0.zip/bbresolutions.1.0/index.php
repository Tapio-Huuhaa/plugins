﻿<?php
require_once(dirname(__FILE__) . '/includes/functions.php');
// Silence is golden.