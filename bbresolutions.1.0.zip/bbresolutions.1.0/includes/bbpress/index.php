﻿<?php
// Silence is golden.