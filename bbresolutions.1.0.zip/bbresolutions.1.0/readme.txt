=== bbResolutions ===
Contributors: alex-ye/Tapio Huuhaa
Tags: bbpress, buddypress, support
Requires at least: 3.0
Tested up to: 4.4.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A bbPress plugin to let you set topic type

== Description ==

= Important Notes: =
* This plugin requires at least PHP 5.3.x.
* This plugin requires bbPress 2.0 at least.
* Tested with WordPress 5.1.

bbResolutions, will let you set topic types (Resolved, Not resolved and Guidance; as default the type is Generic). It's very clean, flexible and
easy-to-install plugin.
== Installation ==

* Upload bbResolutions folder to the plugins directory.
* Activate the plugin through the 'Plugins' menu in WordPress.
* Have fun :-)

== Changelog ==
= 1.0 possible to set also other stickers than resolved
= removed Arabic translation because it is not any usable

= 0.2.4 =
* Add new WP filters "bbr_show_topic_resolution_form" and "bbr_show_topic_resolution_feedback".

= 0.2.3 =
* Change the plugin textdomain to 'bbResolutions'.
* Add a new widget to display a list of recent topics with an option to set the resolution.

= 0.2.2 =
* Fix Bug: bbPress or BuddyPress codes didn't loaded in some cases.

= 0.2 =
* Add the Arabic language.
* Display the topic-resolution sticker.

= 0.1 =
* Initial version.